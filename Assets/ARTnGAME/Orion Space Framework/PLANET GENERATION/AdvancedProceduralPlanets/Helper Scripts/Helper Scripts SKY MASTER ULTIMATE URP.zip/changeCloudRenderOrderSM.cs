using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Artngame.SKYMASTER
{   [ExecuteInEditMode]
    public class changeCloudRenderOrderSM : MonoBehaviour
    {
        public connectSuntoFullVolumeCloudsURP clouds;
        public Transform planetCenter;
        public float planetSize = 10000;
        public float atmosphereStart = 1000;

        // Start is called before the first frame update
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {
            if (Vector3.Distance( Camera.main.transform.position, planetCenter.position) < planetSize + atmosphereStart)
            {
                clouds.renderAfterTransparent = false;
            }
            else
            {
                clouds.renderAfterTransparent = true;
            }
        }
    }
}   
